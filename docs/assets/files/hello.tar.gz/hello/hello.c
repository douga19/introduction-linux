#include <stdio.h>
#include "hello.h"

void hello() {
	printf("Hello world\n");
}
